<?php

$MESS['C_HEADER_TEMP1_DESKTOP_TEMP1_BUTTON'] = 'Заказать звонок';
$MESS['C_HEADER_TEMP1_DESKTOP_TEMP1_BUTTON2'] = 'Запросить расчет';