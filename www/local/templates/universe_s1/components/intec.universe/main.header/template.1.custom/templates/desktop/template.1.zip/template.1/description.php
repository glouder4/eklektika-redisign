<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die() ?>
<?php

use Bitrix\Main\Localization\Loc;

return [
    'name' => Loc::getMessage('C_HEADER_TEMP1_DESKTOP_TEMP1_NAME')
];